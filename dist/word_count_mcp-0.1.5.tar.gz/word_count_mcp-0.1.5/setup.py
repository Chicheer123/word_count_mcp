from setuptools import setup
setup(name='word-count-mcp',
      version='0.1.5',
      py_modules=['word_count_mcp'],
      )