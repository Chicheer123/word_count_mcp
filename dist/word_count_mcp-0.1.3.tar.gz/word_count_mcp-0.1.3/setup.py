from setuptools import setup
setup(name='word_count_mcp',
      version='0.1.3',
      py_modules=['word_count_mcp'],
      )